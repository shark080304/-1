const columns=['首页','部门概况','党群工作','成果转化','校地/校企合作','试验站点','专家团队','定点帮扶/乡村振兴','政策法规','下载中心'];
const nav=document.querySelector('.nav-links');
columns.forEach((name,index)=>{const link=document.createElement('a');link.textContent=name;link.href=index?'#/'+encodeURIComponent(name):'#/';link.dataset.name=name;nav.append(link)});
const listPages={'下载中心':'download','政策法规':'policy','专家团队':'expert-directory','试验站点':'station'};
const clusterPages={
  '党群工作':['支部工作','工会工作'],
  '校地/校企合作':['校地合作','校企合作'],
  '定点帮扶/乡村振兴':['帮扶政策','帮扶动态']
};
const clusterView=document.querySelector('#cluster-view');
const clusterNav=clusterView.querySelector('.cluster-nav');
const clusterHref=name=>'#/'+encodeURIComponent(name);
for(const name of Object.keys(clusterPages)){
  const link=document.createElement('a');
  link.href=clusterHref(name);
  link.dataset.cluster=name;
  if(name==='定点帮扶/乡村振兴'){
    link.setAttribute('aria-label',name);
    const label=document.createElement('span');
    label.append('定点帮扶/',document.createElement('br'),'乡村振兴');
    link.append(label);
  }else link.textContent=name;
  clusterNav.append(link);
}
const clusterEntryTitle=(category,index)=>category+'标题 '+String(index+1).padStart(2,'0');
function showClusterEntry(title,category){
  showDynamic(title);
  const dialog=document.querySelector('#dynamic-dialog');
  dialog.querySelector('.dialog-kicker').textContent=category;
  dialog.querySelector('.dynamic-copy').textContent='此处预留该条目的正文和相关资料，正式内容待补充。';
}
function renderCluster(name){
  const categories=clusterPages[name];
  clusterView.setAttribute('aria-label',name);
  for(const link of clusterNav.querySelectorAll('a')){
    if(link.dataset.cluster===name)link.setAttribute('aria-current','page');
    else link.removeAttribute('aria-current');
  }
  for(const [side,index] of [['left',0],['right',1]]){
    const category=categories[index];
    document.querySelector('#cluster-'+side+'-title').textContent=category;
    const list=document.querySelector('#cluster-'+side+'-list');
    const entries=Array.from({length:15},(_,i)=>{
      const title=clusterEntryTitle(category,i);
      const button=document.createElement('button');
      button.type='button';
      button.className='cluster-row';
      button.setAttribute('aria-haspopup','dialog');
      button.textContent=title;
      button.addEventListener('click',()=>showClusterEntry(title,category));
      return button;
    });
    list.replaceChildren(...entries);
    list.scrollTop=0;
  }
}
function route(){let current;try{current=decodeURIComponent(location.hash.slice(2))}catch{current=''};if(location.hash==='#work')return;const home=!current||current==='首页';document.querySelector('#home-view').hidden=!home;const cluster=Object.hasOwn(clusterPages,current);clusterView.hidden=!cluster;if(cluster)renderCluster(current);const department=current==='部门概况';document.querySelector('#department-view').hidden=!department;document.querySelector('#section-view').hidden=home||current==='成果转化'||Object.hasOwn(listPages,current)||cluster||department;for(const [name,id] of Object.entries(listPages))document.querySelector('#'+id+'-view').hidden=current!==name;document.querySelector('#achievement-view').hidden=current!=='成果转化';if(!home){document.querySelector('#section-title').textContent=current;document.querySelector('#breadcrumb-name').textContent=current}document.querySelectorAll('.nav-links a').forEach(link=>{if(link.dataset.name===(home?'首页':current))link.setAttribute('aria-current','page');else link.removeAttribute('aria-current')});document.title=(home?'首页':current)+' · 安徽农业大学社会合作处';nav.classList.remove('open');document.querySelector('.menu-toggle').setAttribute('aria-expanded','false');window.scrollTo({top:0,behavior:'instant'})}
window.addEventListener('hashchange',route);route();
document.querySelector('.menu-toggle').addEventListener('click',event=>{const open=nav.classList.toggle('open');event.currentTarget.setAttribute('aria-expanded',String(open))});
document.querySelectorAll('.work-circle').forEach(button=>{button.setAttribute('aria-expanded','false');button.addEventListener('click',()=>{document.querySelectorAll('.work-circle').forEach(b=>b.setAttribute('aria-expanded',String(b===button)));document.querySelector('#work-detail-title').textContent=button.dataset.category;document.querySelector('.work-detail').hidden=false})});
document.querySelector('.close-detail').addEventListener('click',()=>{document.querySelector('.work-detail').hidden=true;const active=document.querySelector('.work-circle[aria-expanded=true]');if(active){active.setAttribute('aria-expanded','false');active.focus()}});
document.querySelector('.footer-top').addEventListener('click',event=>{event.preventDefault();window.scrollTo({top:0,behavior:'smooth'})});

// Keep both panels exactly one visible screen below the shared header.
const headerObserver=new ResizeObserver(entries=>document.documentElement.style.setProperty('--header-height',entries[0].target.getBoundingClientRect().height+'px'));
headerObserver.observe(document.querySelector('.site-header'));
const heroTrack=document.querySelector('#hero-track');
const heroDots=[...document.querySelectorAll('.hero-dot')];
const heroSlides=[...heroTrack.querySelectorAll('.hero-slide')];
const heroStatus=document.querySelector('#slide-status');

function currentHeroSlide(){
  return Math.min(heroSlides.length-1,Math.max(0,Math.round(heroTrack.scrollLeft/heroTrack.clientWidth)||0));
}
function updateHeroDots(){
  if(!heroTrack.clientWidth)return;
  const index=currentHeroSlide();
  heroDots.forEach((dot,i)=>dot.setAttribute('aria-pressed',String(i===index)));
  heroSlides.forEach((slide,i)=>slide.setAttribute('aria-hidden',String(i!==index)));
  const message='当前第'+(index+1)+'张，共'+heroSlides.length+'张';
  if(heroStatus.textContent!==message)heroStatus.textContent=message;
}
function showSlide(index){
  const next=Math.max(0,Math.min(heroSlides.length-1,index));
  heroTrack.scrollTo({left:next*heroTrack.clientWidth,behavior:reduced.matches?'instant':'smooth'});
}
heroDots.forEach((dot,index)=>{
  dot.addEventListener('click',()=>showSlide(index));
  dot.addEventListener('keydown',event=>{
    if(!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;
    event.preventDefault();
    const offset=event.key==='ArrowRight'?1:-1;
    const count=heroDots.length;
    const next=event.key==='Home'?0:event.key==='End'?count-1:(index+offset+count)%count;
    showSlide(next);
    heroDots[next].focus();
  });
});
heroTrack.addEventListener('scroll',updateHeroDots,{passive:true});
new ResizeObserver(updateHeroDots).observe(heroTrack);
const track=document.querySelector('#work-track');
const reduced=window.matchMedia('(prefers-reduced-motion: reduce)');
function moveTrack(direction){
  track.scrollBy({left:direction*track.clientWidth/2,behavior:reduced.matches?'instant':'smooth'});
}

const searchDialog=document.querySelector('#search-dialog'),dynamicDialog=document.querySelector('#dynamic-dialog');
document.querySelector('.search-toggle').addEventListener('click',()=>{searchDialog.showModal();document.querySelector('#search-query').focus()});
document.querySelectorAll('.dialog-close').forEach(button=>button.addEventListener('click',()=>button.closest('dialog').close()));
document.querySelectorAll('.site-dialog').forEach(dialog=>dialog.addEventListener('click',event=>{if(event.target!==dialog)return;const box=dialog.getBoundingClientRect();if(event.clientX<box.left||event.clientX>box.right||event.clientY<box.top||event.clientY>box.bottom)dialog.close()}));
function showDynamic(title){document.querySelector('#dynamic-dialog .dialog-kicker').textContent='工作动态';document.querySelector('#dynamic-dialog .dynamic-copy').textContent='该条动态的正文内容待补充。';document.querySelector('#dynamic-title').textContent=title;dynamicDialog.showModal()}
document.querySelectorAll('.oval-label').forEach(button=>button.addEventListener('click',()=>showDynamic(button.textContent)));
const searchable=[...columns.map((title,index)=>({title,type:'column',href:index?'#/'+encodeURIComponent(title):'#/'})),...[...document.querySelectorAll('.oval-label')].map(button=>({title:button.textContent,type:'dynamic'})),...[...document.querySelectorAll('.work-circle')].map(button=>({title:button.dataset.category,type:'work'}))];
document.querySelector('#site-search').addEventListener('submit',event=>{event.preventDefault();const query=document.querySelector('#search-query').value.trim();const list=document.querySelector('#search-results');list.replaceChildren();if(!query){document.querySelector('.search-summary').textContent='请输入搜索关键词。';return}const matches=searchable.filter(item=>item.title.toLocaleLowerCase().includes(query.toLocaleLowerCase()));document.querySelector('.search-summary').textContent=matches.length?`找到 ${matches.length} 条匹配内容`:'未找到匹配内容，请尝试其他关键词。';matches.forEach(item=>{const li=document.createElement('li'),link=document.createElement(item.type==='column'?'a':'button');link.textContent=item.title;if(item.type==='column'){link.href=item.href;link.addEventListener('click',()=>searchDialog.close())}else{link.type='button';link.addEventListener('click',()=>{searchDialog.close();if(item.type==='notice')showNotice(item.title);else if(item.type==='expert')showExpert(item.title);else if(item.type==='technology')showTechnology(item.title,item.category);else if(item.type==='achievement')showAchievement(item.title);else if(item.type==='download')showDownload(item.title);else if(item.type==='directory')showDirectoryEntry(item.title,item.category);else if(item.type==='cluster'||item.type==='department')showClusterEntry(item.title,item.category);else showDynamic(item.title)})}li.append(link);list.append(li)})});

// Notification copy is a placeholder until official announcements are supplied.
const noticeTrack=document.querySelector('#notice-track');
const noticeStatus=document.querySelector('#notice-status');
const notices=[];
for(let group=0;group<6;group++){const card=document.createElement('article');card.className='notice-card';card.setAttribute('aria-label',`第${group+1}组通知公告`);for(let row=0;row<4;row++){const title=`通知公告标题 ${String(group*4+row+1).padStart(2,'0')}`;notices.push(title);const button=document.createElement('button');button.type='button';button.className='notice-row';button.textContent=title;button.setAttribute('aria-haspopup','dialog');button.addEventListener('click',()=>showNotice(title));card.append(button)}noticeTrack.append(card)}
function showNotice(title){showDynamic(title);document.querySelector('#dynamic-dialog .dialog-kicker').textContent='通知公告';document.querySelector('#dynamic-dialog .dynamic-copy').textContent='此处为通知公告详情预留位置，正式标题、发布日期及正文将在后续补充。'}
function noticeStep(){const cards=noticeTrack.querySelectorAll('.notice-card');return cards[1].offsetLeft-cards[0].offsetLeft}
function moveNotices(direction){noticeTrack.scrollBy({left:direction*noticeStep(),behavior:reduced.matches?'instant':'smooth'})}
function enableAutoPaging(rail,move,liveRegion,{pauseOnHover=true,axis="x"}={}){
  const toggle=document.querySelector('.carousel-rotation[aria-controls="'+rail.id+'"]');
  const hover=window.matchMedia('(hover: hover)');
  const vertical=axis==='y';
  const offset=vertical?'scrollTop':'scrollLeft';
  const scrollSize=vertical?'scrollHeight':'scrollWidth';
  const viewSize=vertical?'clientHeight':'clientWidth';
  const backwardKey=vertical?'ArrowUp':'ArrowLeft';
  const forwardKey=vertical?'ArrowDown':'ArrowRight';
  const edge=vertical?'top':'left';
  let playing=!reduced.matches;
  let visible=false;
  let pointer=null;
  let timer;
  function canAdvance(){
    return playing&&visible&&!document.hidden&&pointer===null&&
      !(pauseOnHover&&hover.matches&&rail.matches(':hover'))&&!rail.contains(document.activeElement)&&
      !dynamicDialog.open&&!searchDialog.open&&rail[scrollSize]>rail[viewSize];
  }
  function schedule(){
    clearTimeout(timer);
    if(!canAdvance())return;
    timer=setTimeout(()=>{
      if(!canAdvance())return;
      const end=rail[scrollSize]-rail[viewSize];
      if(rail[offset]>=end-2)rail.scrollTo({[edge]:0,behavior:'instant'});
      else move(1);
    },5000);
  }
  function updateToggle(){
    if(toggle)toggle.textContent=playing?'暂停自动翻页':'开启自动翻页';
    if(liveRegion)liveRegion.setAttribute('aria-live',playing?'off':'polite');
    schedule();
  }
  toggle?.addEventListener('click',()=>{
    playing=!playing;
    updateToggle();
  });
  reduced.addEventListener('change',()=>{
    if(reduced.matches)playing=false;
    updateToggle();
  });
  new IntersectionObserver(([entry])=>{
    visible=entry.isIntersecting&&entry.intersectionRatio>=.5;
    schedule();
  },{threshold:.5}).observe(rail);
  rail.addEventListener('scroll',schedule,{passive:true});
  new ResizeObserver(schedule).observe(rail);
  for(const event of ['mouseenter','mouseleave','focusin','focusout']){
    rail.addEventListener(event,()=>requestAnimationFrame(schedule));
  }
  rail.addEventListener('pointerdown',event=>{
    pointer=event.pointerId;
    schedule();
  });
  for(const event of ['pointerup','pointercancel']){
    window.addEventListener(event,({pointerId})=>{
      if(pointerId!==pointer)return;
      pointer=null;
      schedule();
    });
  }
  document.addEventListener('visibilitychange',schedule);
  for(const dialog of [dynamicDialog,searchDialog])dialog.addEventListener('close',schedule);
  rail.addEventListener('keydown',event=>{
    if(event.key!==backwardKey&&event.key!==forwardKey)return;
    event.preventDefault();
    move(event.key===forwardKey?1:-1);
  });
  enablePanelDrag(rail,axis);
  updateToggle();
}

function updateNotices(){
  const step=noticeStep();
  if(step<=0)return;
  const message='当前从第'+(Math.round(noticeTrack.scrollLeft/step)+1)+'组开始，共6组公告';
  if(noticeStatus.textContent!==message)noticeStatus.textContent=message;
}
noticeTrack.addEventListener('scroll',updateNotices,{passive:true});
new ResizeObserver(updateNotices).observe(noticeTrack);
notices.forEach(title=>searchable.push({title,type:'notice'}));
updateNotices();

// Capture only after a real horizontal drag, preserving normal clicks on rows.
function enablePanelDrag(rail,axis='x'){
  const coordinate=axis==='y'?'clientY':'clientX';
  const offset=axis==='y'?'scrollTop':'scrollLeft';
  let pointer=null;
  let origin=0;
  let scrollOrigin=0;
  let moved=false;

  rail.addEventListener('pointerdown',event=>{
    if(event.pointerType!=='mouse'||event.button!==0)return;
    pointer=event.pointerId;
    origin=event[coordinate];
    scrollOrigin=rail[offset];
    moved=false;
  });
  rail.addEventListener('pointermove',event=>{
    if(event.pointerId!==pointer)return;
    const delta=event[coordinate]-origin;
    if(Math.abs(delta)>5&&!moved){
      moved=true;
      rail.classList.add('dragging');
      rail.setPointerCapture(pointer);
    }
    if(moved){
      event.preventDefault();
      rail[offset]=scrollOrigin-delta;
    }
  });
  function finish(event){
    if(event.pointerId!==pointer)return;
    if(rail.hasPointerCapture(pointer))rail.releasePointerCapture(pointer);
    pointer=null;
    rail.classList.remove('dragging');
    if(moved)setTimeout(()=>moved=false,0);
  }
  rail.addEventListener('pointerup',finish);
  rail.addEventListener('pointercancel',finish);
  window.addEventListener('pointerup',finish);
  rail.addEventListener('click',event=>{
    if(!moved)return;
    event.preventDefault();
    event.stopImmediatePropagation();
  },true);
  rail.addEventListener('dragstart',event=>event.preventDefault());
}
enableAutoPaging(heroTrack,direction=>showSlide(currentHeroSlide()+direction),heroStatus,{pauseOnHover:false});
enableAutoPaging(noticeTrack,moveNotices,noticeStatus);
enableAutoPaging(track,moveTrack);
const expertTrack=document.querySelector('#expert-track'),expertDots=document.querySelector('.expert-dots');
for(let page=0;page<3;page++){const group=document.createElement('article');group.className='expert-group';group.setAttribute('aria-label',`第${page+1}组专家，共六条`);for(let row=0;row<6;row++){const number=String(page*6+row+1).padStart(2,'0'),title=`专家姓名待补充 ${number}`,button=document.createElement('button');button.className='expert-item';button.type='button';button.setAttribute('aria-haspopup','dialog');const label=document.createElement('span');label.textContent=title;const more=document.createElement('small');more.textContent='查看';button.append(label,more);button.addEventListener('click',()=>showExpert(title));group.append(button);searchable.push({title,type:'expert'})}expertTrack.append(group);const dot=document.createElement('button');dot.type='button';dot.setAttribute('aria-label',`显示第${page+1}组专家`);dot.setAttribute('aria-pressed',String(page===0));dot.addEventListener('click',()=>expertTrack.scrollTo({left:page*expertTrack.clientWidth,behavior:reduced.matches?'instant':'smooth'}));expertDots.append(dot)}
function showExpert(title){showDynamic(title);document.querySelector('#dynamic-dialog .dialog-kicker').textContent='专家掠影';document.querySelector('#dynamic-dialog .dynamic-copy').textContent='此处预留专家简介、研究领域及相关成果。正式姓名及介绍将在后续补充。'}
function updateExperts(){const page=Math.round(expertTrack.scrollLeft/expertTrack.clientWidth)||0;document.querySelector('#expert-count').textContent=`0${page+1} / 03`;[...expertDots.children].forEach((dot,index)=>dot.setAttribute('aria-pressed',String(index===page)))}
function moveExperts(direction){const page=Math.round(expertTrack.scrollLeft/expertTrack.clientWidth);expertTrack.scrollTo({left:Math.max(0,Math.min(2,page+direction))*expertTrack.clientWidth,behavior:reduced.matches?'instant':'smooth'})}
expertTrack.addEventListener('scroll',updateExperts,{passive:true});
new ResizeObserver(updateExperts).observe(expertTrack);
enableAutoPaging(expertTrack,moveExperts,document.querySelector('#expert-count'));
updateExperts();

function showTechnology(title,category){showDynamic(title);document.querySelector('#dynamic-dialog .dialog-kicker').textContent=category;document.querySelector('#dynamic-dialog .dynamic-copy').textContent=`此处预留${category}的详细说明、相关资料和联系方式，具体内容将在后续补充。`}
for(const [id,category] of [['demand-list','技术需求'],['promotion-list','技术推介']]){const list=document.querySelector('#'+id);for(let index=1;index<=12;index++){const title=`${category}标题 ${String(index).padStart(2,'0')}`,button=document.createElement('button'),label=document.createElement('span'),more=document.createElement('small');button.type='button';button.className='technology-row';button.setAttribute('aria-haspopup','dialog');label.textContent=title;more.textContent='查看详情';button.append(label,more);button.addEventListener('click',()=>showTechnology(title,category));list.append(button);searchable.push({title,type:'technology',category})}}

for(const list of document.querySelectorAll('.technology-scroll')){
  enableAutoPaging(list,direction=>{
    const rowHeight=list.firstElementChild.getBoundingClientRect().height;
    list.scrollBy({top:direction*rowHeight,behavior:reduced.matches?'instant':'smooth'});
  },null,{axis:'y'});
}

function showAchievement(title){showDynamic(title);document.querySelector('#dynamic-dialog .dialog-kicker').textContent='成果转化';document.querySelector('#dynamic-dialog .dynamic-copy').textContent='此处预留成果介绍、相关技术资料及合作信息，正式内容将在后续补充。'}
for(const [id,prefix] of [['achievement-left','成果信息标题'],['achievement-right','合作信息标题']]){const list=document.querySelector('#'+id);for(let index=1;index<=12;index++){const title=`${prefix} ${String(index).padStart(2,'0')}`,button=document.createElement('button'),span=document.createElement('span');button.type='button';button.setAttribute('aria-haspopup','dialog');span.textContent=title;button.append(span);button.addEventListener('click',()=>showAchievement(title));list.append(button);searchable.push({title,type:'achievement'})}}
const releaseTrack=document.querySelector('.release-track'),releasePrev=document.querySelector('.release-prev'),releaseNext=document.querySelector('.release-next');
for(let page=0;page<4;page++){const group=document.createElement('article');group.className='release-group';group.setAttribute('aria-label',`第${page+1}组成果发布`);for(let row=0;row<3;row++){const title=`成果发布标题 ${String(page*3+row+1).padStart(2,'0')}`,button=document.createElement('button');button.type='button';button.textContent=title;button.setAttribute('aria-haspopup','dialog');button.addEventListener('click',()=>showAchievement(title));group.append(button);searchable.push({title,type:'achievement'})}releaseTrack.append(group)}
function updateRelease(){const page=Math.round(releaseTrack.scrollLeft/releaseTrack.clientWidth)||0;releasePrev.disabled=page===0;releaseNext.disabled=page===3;document.querySelector('#release-count').textContent=`0${page+1} / 04`}
function moveRelease(direction){const page=Math.round(releaseTrack.scrollLeft/releaseTrack.clientWidth)||0;releaseTrack.scrollTo({left:Math.max(0,Math.min(3,page+direction))*releaseTrack.clientWidth,behavior:reduced.matches?'instant':'smooth'})}
releasePrev.addEventListener('click',()=>moveRelease(-1));releaseNext.addEventListener('click',()=>moveRelease(1));releaseTrack.addEventListener('scroll',updateRelease);releaseTrack.addEventListener('keydown',event=>{if(['ArrowLeft','ArrowRight'].includes(event.key)){event.preventDefault();moveRelease(event.key==='ArrowRight'?1:-1)}});new ResizeObserver(updateRelease).observe(releaseTrack);enablePanelDrag(releaseTrack);updateRelease();

function showDownload(title){showDynamic(title);document.querySelector('#dynamic-dialog .dialog-kicker').textContent='下载中心';document.querySelector('#dynamic-dialog .dynamic-copy').textContent='此处预留资料说明和下载入口。正式文件上传后即可提供下载。'}
const downloadList=document.querySelector('#download-list');for(let index=1;index<=21;index++){const title=`下载资料标题 ${String(index).padStart(2,'0')}`,button=document.createElement('button'),label=document.createElement('span'),note=document.createElement('small');button.type='button';button.className='download-row';button.setAttribute('aria-haspopup','dialog');label.textContent=title;note.textContent='文件待上传';button.append(label,note);button.addEventListener('click',()=>showDownload(title));downloadList.append(button);searchable.push({title,type:'download'})}

function showDirectoryEntry(title,category){
  showDynamic(title);
  document.querySelector('#dynamic-dialog .dialog-kicker').textContent=category;
  document.querySelector('#dynamic-dialog .dynamic-copy').textContent=category==='政策法规'
    ? '此处预留政策文件的正文、发布日期和来源，正式资料待补充。'
    : category==='试验站点'
      ? '此处预留试验站简介、试验方向和相关资料，正式内容待补充。'
      : '此处预留专家简介、研究领域和相关成果，正式资料待补充。';
}
for(const {id,category,prefix} of [
  {id:'policy',category:'政策法规',prefix:'政策法规标题'},
  {id:'expert-directory',category:'专家团队',prefix:'专家姓名待补充'},
  {id:'station',category:'试验站点',prefix:'试验站点名称待补充'}
]){
  const list=document.querySelector('#'+id+'-list');
  for(let index=1;index<=21;index++){
    const title=prefix+' '+String(index).padStart(2,'0');
    const button=document.createElement('button');
    button.type='button';
    button.className='download-row';
    button.setAttribute('aria-haspopup','dialog');
    const label=document.createElement('span');
    label.textContent=title;
    const note=document.createElement('small');
    note.textContent='查看详情';
    button.append(label,note);
    button.addEventListener('click',()=>showDirectoryEntry(title,category));
    list.append(button);
    searchable.push({title,type:'directory',category});
  }
}

for(const categories of Object.values(clusterPages)){
  for(const category of categories){
    for(let index=0;index<15;index++)searchable.push({title:clusterEntryTitle(category,index),type:'cluster',category});
  }
}

for(const [id,category] of [['intro-list','部门简介'],['setup-list','部门设置']]){
  const list=document.querySelector('#'+id);
  for(let i=0;i<14;i++){
    const title=clusterEntryTitle(category,i);
    const button=document.createElement('button');
    button.type='button';
    button.className='department-row';
    button.setAttribute('aria-haspopup','dialog');
    button.textContent=title;
    button.addEventListener('click',()=>showClusterEntry(title,category));
    list.append(button);
    searchable.push({title,type:'department',category});
  }
}
const staff=Array.from({length:10},(_,i)=>({
  name:'',role:'',position:'',phone:'',address:'',photo:'',label:'人员 '+String(i+1).padStart(2,'0')
}));
const staffTrack=document.querySelector('.staff-track');
const staffPrev=document.querySelector('.staff-prev');
const staffNext=document.querySelector('.staff-next');
const staffFields=document.querySelector('#staff-fields');
const staffPhoto=document.querySelector('#staff-photo');
function selectStaff(index){
  const person=staff[index];
  [...staffTrack.children].forEach((button,i)=>button.setAttribute('aria-pressed',String(i===index)));
  const rows=[['姓名',person.name||person.label+'（姓名待补充）'],['职务',person.role],['岗位',person.position],['电话',person.phone],['地址',person.address]];
  staffFields.replaceChildren(...rows.flatMap(([label,value])=>{
    const term=document.createElement('dt'),description=document.createElement('dd');
    term.textContent=label+'：';
    description.textContent=value||'待补充';
    return [term,description];
  }));
  staffPhoto.src=person.photo||'assets/department-portrait.svg';
  staffPhoto.alt=person.photo?(person.name||person.label)+'照片':person.label+'的照片待补充';
}
staff.forEach((person,index)=>{
  const button=document.createElement('button');
  const avatar=document.createElement('span');
  button.type='button';
  button.className='staff-person';
  button.setAttribute('aria-pressed','false');
  avatar.className='staff-avatar';
  avatar.textContent=person.name||person.label;
  if(person.photo){
    const image=document.createElement('img');
    image.src=person.photo;
    image.alt='';
    avatar.prepend(image);
  }
  button.append(avatar);
  button.addEventListener('click',()=>selectStaff(index));
  staffTrack.append(button);
});
function updateStaffControls(){
  staffPrev.disabled=staffTrack.scrollLeft<2;
  staffNext.disabled=staffTrack.scrollLeft>=staffTrack.scrollWidth-staffTrack.clientWidth-2;
}
function moveStaff(direction){
  staffTrack.scrollBy({left:direction*staffTrack.clientWidth,behavior:reduced.matches?'instant':'smooth'});
}
staffPrev.addEventListener('click',()=>moveStaff(-1));
staffNext.addEventListener('click',()=>moveStaff(1));
staffTrack.addEventListener('scroll',updateStaffControls);
staffTrack.addEventListener('keydown',event=>{
  if(event.key!=='ArrowLeft'&&event.key!=='ArrowRight')return;
  event.preventDefault();
  moveStaff(event.key==='ArrowRight'?1:-1);
});
new ResizeObserver(updateStaffControls).observe(staffTrack);
enablePanelDrag(staffTrack);
selectStaff(0);
updateStaffControls();
document.querySelector('#jump-to-staff').addEventListener('click',()=>{
  const staffSection=document.querySelector('#department-staff');
  const top=window.scrollY+staffSection.getBoundingClientRect().top-document.querySelector('.site-header').getBoundingClientRect().bottom;
  window.scrollTo({top,behavior:reduced.matches?'instant':'smooth'});
});

const friendDropdown=document.querySelector('.friend-dropdown');
const friendSummary=friendDropdown.querySelector('summary');
const friendMenu=friendDropdown.querySelector('.friend-menu');
function fitFriendMenu(){
  if(!friendDropdown.open)return;
  const bounds=friendSummary.getBoundingClientRect();
  const above=bounds.top-10;
  const below=window.innerHeight-bounds.bottom-10;
  const openDown=above<150&&below>above;
  friendDropdown.dataset.menuDirection=openDown?'down':'up';
  friendDropdown.style.setProperty('--friend-menu-space',Math.max(0,openDown?below:above)+'px');
}
friendDropdown.addEventListener('toggle',fitFriendMenu);
window.addEventListener('resize',fitFriendMenu);
window.addEventListener('scroll',fitFriendMenu,{passive:true});
friendMenu.addEventListener('click',event=>{
  const link=event.target.closest('a');
  if(!link)return;
  friendMenu.querySelector('[aria-current]')?.removeAttribute('aria-current');
  link.setAttribute('aria-current','true');
  friendSummary.querySelector('.friend-selection').textContent=link.textContent;
  friendDropdown.open=false;
  friendSummary.focus({preventScroll:true});
});
friendDropdown.addEventListener('keydown',event=>{
  if(event.key!=='Escape'||!friendDropdown.open)return;
  event.preventDefault();
  friendDropdown.open=false;
  friendSummary.focus({preventScroll:true});
});
document.addEventListener('click',event=>{
  if(friendDropdown.open&&!friendDropdown.contains(event.target))friendDropdown.open=false;
});
window.addEventListener('hashchange',()=>friendDropdown.open=false);

// Replay each illustration when its section comes back into view.
if ('IntersectionObserver' in window) {
  const artEntrances = new IntersectionObserver(entries => {
    for (const {target, intersectionRatio} of entries) {
      if (intersectionRatio >= 0.25) {
        target.dataset.artEntrance = 'playing';
      } else if (intersectionRatio <= 0.10) {
        target.dataset.artEntrance = 'waiting';
      }
    }
  }, {rootMargin: '-12% 0px -12% 0px', threshold: [0.10, 0.25]});

  for (const section of document.querySelectorAll('#work, #announcements, #experts, #technology')) {
    section.dataset.artEntrance = 'waiting';
    artEntrances.observe(section);
  }
}
